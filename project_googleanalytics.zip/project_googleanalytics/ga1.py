import math
inputfile=open("gatags.txt","r")
inputfile1=open("gatagspostcount.txt","r")
pv={}
upv={}
score1={}
score2={}
total=0
postcount={}
totalupv=0.0
totalpvminupv=0.0

for line in inputfile:
	total+=1
	line=line.replace("\n","")
	content=line.split("\t")
	tags=content[0].split(",")
	for s in tags:
		t=s.lower()
		if t not in pv:
			pv.update({t:int(content[1])})
		else:
			pv[t]+=int(content[1])
		if t not in upv:
			upv.update({t:int(content[2])})
		else:
			upv[t]+=int(content[2])
for l in inputfile1:
	# arr= [['tagname',count],]
	l=l.replace("\n","")
	tagcontent=l.split("\t")
	tag=tagcontent[0].lower()
	count=int(tagcontent[1])
	if tag not in postcount:
		postcount.update({tag:count})

for key in upv:
#	print type(upv[key])
	print upv[key]
#	totalupv+=int((upv[key]))
for key in pv:
	totalpvminupv+=int((pv[key]-upv[key]))

for key in postcount:
	if key not in score1:

		score1.update({key:float(upv[key])*math.log(float(total)/float(postcount[key]))})
for key in postcount:
	score2.update({key:float(float(pv[key])-float(upv[key]))*math.log(float(total)/float(postcount[key]))})
outputfile=open("score2.txt","a")
outputfile1=open("score1.txt","a")
for key in score1:
	outputfile1.write(key+"\t"+str(score1[key])+"\n")
	outputfile.write(key+"\t"+str(score2[key])+"\n")
