import re
import urllib2
from urllib2 import urlopen
import json
import requests
outputfile1=open("gatagspostcount.txt","w")

inputfile=open("gapostlinks.txt","r")
i=0
outputfile=open("gapostlinkscleaned.txt","a")
alpha=1
gadbad=[]
tagpostcount={}
for line in inputfile:
	print line
	print alpha
	tags=[]
	try:
		line=line.replace("\n","")
		url="http://"+str(line)+"?json=1"
		response=urllib2.urlopen(url)
		data=response.read()
	
		jsondata=json.loads(data)

		print jsondata["post"]["tags"]
		for j in range(len(jsondata["post"]["tags"])):
			tags.append(jsondata["post"]["tags"][j]["title"])
			if jsondata["post"]["tags"][j]["title"].lower() not in tagpostcount:
				tagpostcount.update({jsondata["post"]["tags"][j]["title"].lower():jsondata["post"]["tags"][j]["post_count"]})
		for k in range(len(tags)):
			if k==len(tags)-1:
				outputfile.write(tags[k])
			else:
				outputfile.write(tags[k]+",")
		outputfile.write("\n")
	except (ValueError, urllib2.HTTPError):
		print "Exception"
		gadbad.append(alpha)
		outputfile.write('Exception\n')

	alpha+=1
print tagpostcount
for key in tagpostcount:
	outputfile1.write(key+"\t"+str(tagpostcount[key])+"\n")
print gadbad
#for line in inputfile:
#	if i > -1:
#		arr = repattern.findall(line)
#		if(arr):
#			line = line.replace(arr[0],'')
#		line=line.replace("?","")

#		print line
		#outputfile.write(line)
#	i+=1	
